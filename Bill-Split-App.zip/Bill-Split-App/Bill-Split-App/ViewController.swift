//
//  ViewController.swift
//  Bill-Split-App
//
//  Created by user222625 on 10/1/22.
//

import UIKit

class ViewController: UIViewController {

    var tipPercent:Int? = nil
    @IBAction func tipAction(_ sender: UIButton) {
        sender.backgroundColor = UIColor.black
        var tip:String? = sender.titleLabel?.text
        if(tip == "0 %"){
            tipPercent = 0
        }else if(tip == "10 %"){
            tipPercent = 10
        }else{
            tipPercent = 20
        }
        
    }
    @IBOutlet weak var numberOfPeople: UITextView!
    @IBOutlet weak var amount: UITextField!
    @IBAction func calculateAction(_ sender: UIButton) {
        
        let secondViewController : SecondViewController = (self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as? SecondViewController)!
        var amountPerPerson:Double? = Double(amount.text!) ?? 0
        var person:Double? = Double(numberOfPeople.text!) ?? 1
        
        var totalTipPercent:Double? = 1 + Double(tipPercent!) / Double(100)
        var totalAmountWithTip:Double? = Double(amountPerPerson!) * Double(totalTipPercent!)
        
        var res:Double? = Double(totalAmountWithTip!) / Double(person!) ?? 0
        secondViewController.amountForEach = String(res!)
        self.navigationController?.pushViewController(secondViewController, animated: true)
                                                    
        
        
    }
    @IBAction func incrementAction(_ sender: UIButton) {
        var people:Int? = Int(numberOfPeople.text!) ?? 1
        numberOfPeople.text = String(people! + 1)
        
        
    }
    @IBAction func decrementAction(_ sender: UIButton) {
        var people:Int? = Int(numberOfPeople.text!) ?? 1
        if(people! > 2){
            
            
            numberOfPeople.text = String(people! - 1)
        }else{
            numberOfPeople.text = String(1)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

