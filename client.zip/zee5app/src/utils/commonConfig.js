export const headerConfig = {
  headers: { "Content-Type": "application/json" },
};
