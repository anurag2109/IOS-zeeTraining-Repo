import {
  ADD_MOVIE,
  DELETE_MOVIE,
  GET_MOVIE,
  GET_MOVIES,
  UPDATE_MOVIE,
} from "../types";

const initialState = {
  movies: [],
  movie: {},
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case GET_MOVIES:
      return { ...state, movies: payload, movie: null };
    case GET_MOVIE:
      return { ...state, movie: payload };
    case ADD_MOVIE:
      return { ...state, movie: payload };
    case DELETE_MOVIE:
      return { ...state, movie: payload };
    case UPDATE_MOVIE:
      // state.movies.filter((movie) => movie.id !== payload);
      return { ...state, movie: payload };
    default:
      return state;
  }
};
