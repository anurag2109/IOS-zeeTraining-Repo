package com.zee.zee5app.enums;

public enum EROLE {
	
	ROLE_USER,
	ROLE_ADMIN,
	ROLE_MOD;

}
