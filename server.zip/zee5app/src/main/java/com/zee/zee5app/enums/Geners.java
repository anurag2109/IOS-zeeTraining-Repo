package com.zee.zee5app.enums;

public enum Geners {
	ACTION,
	DRAMA,
	COMEDY,
	SCIENCE_FICTION,
	REALISTIC_FICTION
}
