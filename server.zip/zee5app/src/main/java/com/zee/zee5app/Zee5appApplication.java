package com.zee.zee5app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Zee5appApplication {

	public static void main(String[] args) {
		SpringApplication.run(Zee5appApplication.class, args);
	}

}
