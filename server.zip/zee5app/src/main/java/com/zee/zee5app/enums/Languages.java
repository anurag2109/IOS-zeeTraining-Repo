package com.zee.zee5app.enums;

public enum Languages {
	ENGLISH,
	HINDI,
	KANNADA,
	TELGU,
	TAMIL,
	MALAYALAM,
	MARATHI,
	BHOJPURI,
	MAITHILI
}
