package com.zee.zee5app.exceptions.apierror;

public abstract class ApiSubError {

}
